package com.yedam.likeIt.vo;

import lombok.Data;

@Data
public class LikeItVO {

	private int memberNo;
	private int bookNo;
	private String img;
	private String name;
	private String author;
	private String comp;
	private int price;


}
