package com.yedam.data;

public interface DataMapper {
	int insertData();
}
