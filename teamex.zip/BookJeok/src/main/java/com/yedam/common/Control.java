package com.yedam.common;



public interface Control {
	public void execute(HttpServletRequest req, HttpServletResponse resp);

}
