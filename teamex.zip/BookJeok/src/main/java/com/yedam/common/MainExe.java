package com.yedam.common;

public class MainExe {
	
	public static void main(String[] args) {
		// 테스트
		
	}

}
