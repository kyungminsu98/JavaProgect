package com.yedam.orderItem.vo;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class OrderItemVO {
	private String mName;
	private String phone;
	private String adress;
	private int point;
	
}
