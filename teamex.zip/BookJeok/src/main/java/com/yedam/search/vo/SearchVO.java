package com.yedam.search.vo;

import lombok.Data;

@Data
public class SearchVO {
	
	private int searchNo;
	private String keyword;
	private String sdt;
	private int hit;
}
